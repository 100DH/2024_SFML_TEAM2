#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include "Title.h"

enum class GameState { StartScreen, Playing, GameOver };

void Icegamemain()
{
    sf::RenderWindow window(sf::VideoMode(800, 600), "Air Hockey Game");

    GameState gameState = GameState::StartScreen;

    // �е� ���� (���� ���)
    sf::CircleShape paddle1(25); // ������ 25
    paddle1.setPosition(50, 250);
    paddle1.setFillColor(sf::Color::Red);

    sf::CircleShape paddle2(25); // ������ 25
    paddle2.setPosition(700, 250);
    paddle2.setFillColor(sf::Color::Blue);

    // �� ����
    sf::CircleShape puck(15);
    puck.setPosition(400, 300);
    puck.setFillColor(sf::Color::Black);

    // ���� �ӵ�
    sf::Vector2f puckVelocity(0.1f, 0.1f);

    // ��� ���� (�簢�� ���)
    sf::RectangleShape goal1(sf::Vector2f(20, 100));
    goal1.setPosition(0, 250);
    goal1.setFillColor(sf::Color::Green);

    sf::RectangleShape goal2(sf::Vector2f(20, 100));
    goal2.setPosition(780, 250);
    goal2.setFillColor(sf::Color::Green);

    // ���� ����
    int score1 = 0;
    int score2 = 0;

    // ��Ʈ ����
    sf::Font font;
    if (!font.loadFromFile("resources/tuffy.ttf")) {
        // ��Ʈ�� �ε��ϴ� �� ������ ���� ��� ó��
    }

    // ���� �ؽ�Ʈ ����
    sf::Text scoreText1;
    scoreText1.setFont(font);
    scoreText1.setCharacterSize(24);
    scoreText1.setFillColor(sf::Color::Black);
    scoreText1.setPosition(10, 10);

    sf::Text scoreText2;
    scoreText2.setFont(font);
    scoreText2.setCharacterSize(24);
    scoreText2.setFillColor(sf::Color::Black);
    scoreText2.setPosition(760, 10);

    // ���� ���� �ؽ�Ʈ ����
    sf::Text gameOverText;
    gameOverText.setFont(font);
    gameOverText.setCharacterSize(48);
    gameOverText.setFillColor(sf::Color::Red);
    gameOverText.setString("GAME OVER");
    gameOverText.setPosition(270, 200);

    // ���� ȭ�� �ؽ�Ʈ ����
    sf::Text startText;
    startText.setFont(font);
    startText.setCharacterSize(48);
    startText.setFillColor(sf::Color::White);
    startText.setString("START");
    startText.setPosition(335, 150);

    //��Ű ���� �ؽ�Ʈ ����
    sf::Text titleText;
    titleText.setFont(font);
    titleText.setCharacterSize(48);
    titleText.setFillColor(sf::Color::White);
    titleText.setString("AIR HOCKEY GAME");
    // �߾� ��ܿ� ��ġ
    sf::FloatRect titleBounds = titleText.getLocalBounds();
    titleText.setPosition((window.getSize().x - titleBounds.width) / 2, 50);

    // BACK ��ư �ؽ�Ʈ ����
    sf::Text backText;
    backText.setFont(font);
    backText.setCharacterSize(30);
    backText.setFillColor(sf::Color::Black);
    backText.setString("BACK");
    backText.setPosition(370, 300);

    // ���� �� ����
    sf::RectangleShape centerLine(sf::Vector2f(5, 600)); // ũ�� ����
    centerLine.setPosition(400, 0); // ��ġ ����
    centerLine.setFillColor(sf::Color::White);

    // ȭ�� �߾ӿ� ��� �� ����
    sf::CircleShape centerCircle(50);
    centerCircle.setPosition(355, 250); // ��ġ ����
    centerCircle.setFillColor(sf::Color::Transparent);
    centerCircle.setOutlineColor(sf::Color::White);
    centerCircle.setOutlineThickness(5);

    sf::Texture mainPageBackgroundImage;
    if (!mainPageBackgroundImage.loadFromFile("resources/background.png"))
    {
        // �̹����� �ε��ϴ� �� ������ ���� ��� ó��

    }
    // �̹��� �ε�
    sf::Texture backgroundImage;
    if (!backgroundImage.loadFromFile("resources/ice.jpg"))
    {
        // �̹����� �ε��ϴ� �� ������ ���� ��� ó��

    }
    sf::Sprite mainPageBackgroundSprite;
    mainPageBackgroundSprite.setTexture(mainPageBackgroundImage);

    sf::Vector2u textureSize = mainPageBackgroundImage.getSize();
    sf::Vector2u windowSize = window.getSize();

    float scaleX = static_cast<float>(windowSize.x) / textureSize.x;
    float scaleY = static_cast<float>(windowSize.y) / textureSize.y;

    mainPageBackgroundSprite.setScale(scaleX, scaleY);
    // �̹����� ���� ��������Ʈ ����
    sf::Sprite backgroundSprite;
    backgroundSprite.setTexture(backgroundImage);

    // ȿ���� �ε�
    sf::SoundBuffer paddleHitBuffer;
    if (!paddleHitBuffer.loadFromFile("resources/hit.wav"))
    {
        // ȿ������ �ε��ϴ� �� ������ ���� ��� ó��
    }
    sf::Sound paddleHitSound;
    paddleHitSound.setBuffer(paddleHitBuffer);

    bool gameOver = false;

    while (window.isOpen())
    {
        sf::Event event;

        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();

            if (gameState == GameState::StartScreen && event.type == sf::Event::MouseButtonPressed)
            {
                if (event.mouseButton.button == sf::Mouse::Left)
                {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    sf::FloatRect startButtonRect = startText.getGlobalBounds();
                    if (startButtonRect.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)))
                    {
                        gameState = GameState::Playing;
                    }
                }
            }

            if (gameState == GameState::GameOver && event.type == sf::Event::MouseButtonPressed)
            {
                if (event.mouseButton.button == sf::Mouse::Left)
                {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    sf::FloatRect backButtonRect = backText.getGlobalBounds();
                    if (backButtonRect.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)))
                    {
                        gameState = GameState::StartScreen;
                        score1 = 0;
                        score2 = 0;
                        gameOver = false;
                        puck.setPosition(400, 300);
                        puckVelocity = sf::Vector2f(0.1f, 0.1f);
                    }
                }
            }
        }

        if (gameState == GameState::Playing && !gameOver) {
            // �÷��̾� �Է� ó��
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) paddle1.move(0, -0.2f);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) paddle1.move(0, 0.2f);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) paddle1.move(-0.2f, 0);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) paddle1.move(0.2f, 0);

            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) paddle2.move(0, -0.2f);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) paddle2.move(0, 0.2f);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) paddle2.move(-0.2f, 0);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) paddle2.move(0.2f, 0);

            // �е��� ȭ�� ������ ������ �ʵ��� ��ġ ����
            if (paddle1.getPosition().x < 0)
            {
                paddle1.setPosition(0, paddle1.getPosition().y);
            }
            if (paddle1.getPosition().x + paddle1.getRadius() * 2 > 400)
            {
                paddle1.setPosition(400 - paddle1.getRadius() * 2, paddle1.getPosition().y);
            }
            if (paddle1.getPosition().y < 0)
            {
                paddle1.setPosition(paddle1.getPosition().x, 0);
            }
            if (paddle1.getPosition().y + paddle1.getRadius() * 2 > 600)
            {
                paddle1.setPosition(paddle1.getPosition().x, 600 - paddle1.getRadius() * 2);
            }

            if (paddle2.getPosition().x < 400)
            {
                paddle2.setPosition(400, paddle2.getPosition().y);
            }
            if (paddle2.getPosition().x + paddle2.getRadius() * 2 > 800)
            {
                paddle2.setPosition(800 - paddle2.getRadius() * 2, paddle2.getPosition().y);
            }
            if (paddle2.getPosition().y < 0)
            {
                paddle2.setPosition(paddle2.getPosition().x, 0);
            }
            if (paddle2.getPosition().y + paddle2.getRadius() * 2 > 600)
            {
                paddle2.setPosition(paddle2.getPosition().x, 600 - paddle2.getRadius() * 2);
            }

            // �� ������
            puck.move(puckVelocity);

            // ���� ��� �浹 ���� �� �ݻ�
            if (puck.getPosition().y <= 0 || puck.getPosition().y >= 585)
            {
                puckVelocity.y = -puckVelocity.y;
            }

            // ��븦 �������� ���
            if (puck.getPosition().x <= 0)
            {
                // ��� ���� ���� ���� ��� ���� ����
                if ((puck.getPosition().y >= 250 && puck.getPosition().y <= 350))
                {
                    score2++;
                    puck.setPosition(400, 300);
                    puckVelocity = sf::Vector2f(0.1f, 0.1f);
                    // ȿ���� ���
                    paddleHitSound.play();
                }
                else
                {
                    puckVelocity.x = -puckVelocity.x;
                    // ȿ���� ���
                    paddleHitSound.play();
                }
            }
            else if (puck.getPosition().x >= 785)
            {
                if ((puck.getPosition().y >= 250 && puck.getPosition().y <= 350))
                {
                    score1++;
                    puck.setPosition(400, 300);
                    puckVelocity = sf::Vector2f(-0.1f, 0.1f);
                    // ȿ���� ���
                    paddleHitSound.play();
                }
                else
                {
                    puckVelocity.x = -puckVelocity.x;
                    // ȿ���� ���
                    paddleHitSound.play();
                }
            }

            // �е�� ���� �浹 ����
            if (paddle1.getGlobalBounds().intersects(puck.getGlobalBounds()) ||
                paddle2.getGlobalBounds().intersects(puck.getGlobalBounds()))
            {
                puckVelocity.x = -puckVelocity.x;
                // ȿ���� ���
                paddleHitSound.play();
            }

            // ���� ������Ʈ
            scoreText1.setString(std::to_string(score1));
            scoreText2.setString(std::to_string(score2));

            // ���� ���� üũ
            if (score1 >= 3 || score2 >= 3) {
                gameOver = true;
                gameState = GameState::GameOver;
            }
        }

        // ȭ�� ������Ʈ
        window.clear();
        // ��� �̹��� �׸���
        if (gameState == GameState::StartScreen) {
            window.draw(mainPageBackgroundSprite);
            window.draw(startText);
            window.draw(titleText);
        }
        else if (gameState == GameState::Playing) {
            window.draw(backgroundSprite);
            window.draw(centerLine);
            window.draw(centerCircle);
            window.draw(paddle1);
            window.draw(paddle2);
            window.draw(puck);
            window.draw(goal1);
            window.draw(goal2);
            window.draw(scoreText1);
            window.draw(scoreText2);
        }
        else if (gameState == GameState::GameOver) {
            window.draw(backgroundSprite);
            window.draw(gameOverText);
            window.draw(backText);
        }

        window.display();
    }
}
