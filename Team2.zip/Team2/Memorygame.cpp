﻿#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <sstream>
#include "Title.h"

const int WINDOW_WIDTH = 900;
const int WINDOW_HEIGHT = 900;
const int CARD_SIZE = 100;
int GRID_WIDTH = 4;  // 기본 그리드 너비 (쉬운 모드)
int GRID_HEIGHT = 4; // 기본 그리드 높이 (쉬운 모드)
const int GAME_DURATION = 60; // 게임 지속 시간 (초 단위)

class Card {
public:
    sf::RectangleShape shape;
    int id;
    sf::Color color;
    bool isFlipped;
    bool isMatched;

    Card(int id, float x, float y) : id(id), isFlipped(false), isMatched(false) {
        shape.setSize(sf::Vector2f(CARD_SIZE, CARD_SIZE));
        shape.setPosition(x, y);
        isFlipped = false;
        isMatched = false;
    }

    void flip() {
        isFlipped = !isFlipped;
        if (isFlipped) {
            shape.setFillColor(color);
        }
        else {
            shape.setFillColor(sf::Color::White);
        }
    }

    // 색상 비교 함수
    bool isSameColor(const Card& other) const {
        return color == other.color;
    }
};

// 모든 카드가 맞춰졌는지 확인하는 함수
bool allCardsMatched(const std::vector<Card>& cards) {
    for (const Card& card : cards) {
        if (!card.isMatched) {
            return false;
        }
    }
    return true;
}

class Game {
private:
    std::vector<Card> cards;
    sf::RenderWindow& window;
    int flippedCard;
    sf::Clock clock;
    sf::Clock gameClock; // 게임 시간을 추적하는 시계
    bool delay;
    int score;
    sf::Font font;
    sf::Text scoreText;
    sf::Text timerText; // 남은 시간을 표시하는 텍스트
    sf::SoundBuffer flipBuffer;
    sf::Sound flipSound;

public:
    Game(sf::RenderWindow& window, int gridWidth, int gridHeight) : window(window), flippedCard(-1), delay(false), score(0) {
        GRID_WIDTH = gridWidth;
        GRID_HEIGHT = gridHeight;

        if (!font.loadFromFile("resources/tuffy.ttf")) {
            // 폰트 로드 실패
            // 오류 처리
        }

        if (!flipBuffer.loadFromFile("resources/click.wav")) {
            // 사운드 로드 실패
            // 오류 처리
        }
        flipSound.setBuffer(flipBuffer);

        scoreText.setFont(font);
        scoreText.setCharacterSize(30);
        scoreText.setFillColor(sf::Color::White);
        scoreText.setPosition(10, WINDOW_HEIGHT - 50);

        timerText.setFont(font);
        timerText.setCharacterSize(30);
        timerText.setFillColor(sf::Color::White);
        timerText.setPosition(WINDOW_WIDTH - 150, 10); // 타이머 텍스트를 오른쪽 상단에 위치

        std::vector<sf::Color> colors;
        if (GRID_WIDTH == 4 && GRID_HEIGHT == 4) {
            // 4x4 그리드에 대해 제한된 색상 사용
            colors = {
                sf::Color(255, 0, 0),     // 빨강
                sf::Color(0, 255, 0),     // 초록
                sf::Color(0, 0, 255),     // 파랑
                sf::Color(255, 255, 0),   // 노랑
                sf::Color(255, 0, 255),   // 마젠타
                sf::Color(0, 255, 255),   // 시안
                sf::Color(255, 128, 0),   // 주황
                sf::Color(128, 0, 128)    // 보라
            };
        }
        else {
            // 다른 그리드 크기에 대해 모든 색상 사용
            colors = {
                sf::Color(255, 0, 0),       // 빨강
                sf::Color(0, 255, 0),       // 초록
                sf::Color(0, 0, 255),       // 파랑
                sf::Color(255, 255, 0),     // 노랑
                sf::Color(255, 0, 255),     // 마젠타
                sf::Color(0, 255, 255),     // 시안
                sf::Color(245, 222, 179),   // 밀
                sf::Color(255, 128, 0),     // 주황
                sf::Color(128, 0, 128),     // 보라
                sf::Color(128, 128, 0),     // 올리브
                sf::Color(0, 128, 128),     // 청록
                sf::Color(128, 0, 0),       // 밤색
                sf::Color(128, 128, 128),   // 회색
                sf::Color(192, 192, 192),   // 은색
                sf::Color(255, 192, 203),   // 분홍
                sf::Color(255, 165, 0),     // 오렌지 레드
                sf::Color(173, 216, 230),   // 연한 파랑
                sf::Color(253, 245, 230)    // 올드 레이스
            };
        }

        std::vector<sf::Color> shuffledColors;
        for (const auto& color : colors) {
            shuffledColors.push_back(color);
            shuffledColors.push_back(color);
        }
        std::random_shuffle(shuffledColors.begin(), shuffledColors.end());

        int horizontalMargin = (WINDOW_WIDTH - GRID_WIDTH * CARD_SIZE - (GRID_WIDTH - 1) * 10) / 2;
        int verticalMargin = (WINDOW_HEIGHT - GRID_HEIGHT * CARD_SIZE - (GRID_HEIGHT - 1) * 10) / 2;

        for (int i = 0; i < GRID_HEIGHT; ++i) {
            for (int j = 0; j < GRID_WIDTH; ++j) {
                int index = i * GRID_WIDTH + j;
                cards.emplace_back(index, j * (CARD_SIZE + 10) + horizontalMargin, i * (CARD_SIZE + 10) + verticalMargin);
                cards.back().color = shuffledColors[index];
            }
        }

        updateScoreText(); // 점수 텍스트 초기화

    }

    void updateScoreText() {
        std::stringstream ss;
        ss << "Score: " << score;
        scoreText.setString(ss.str());
    }

    void updateTimerText(int remainingTime) {
        std::stringstream ss;
        ss << "Time: " << remainingTime;
        timerText.setString(ss.str());
    }

    bool run() {
        gameClock.restart(); // 게임 시계 시작
        while (window.isOpen()) {
            int elapsedTime = gameClock.getElapsedTime().asSeconds();
            int remainingTime = GAME_DURATION - elapsedTime;

            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    window.close();
                    return false;
                }

                if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
                    // ESC 키 눌렀을 때 메뉴로 돌아가기
                    return true;
                }

                if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                    if (!delay) {
                        sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                        for (size_t i = 0; i < cards.size(); ++i) {
                            if (cards[i].shape.getGlobalBounds().contains(mousePos.x, mousePos.y) && !cards[i].isFlipped && !cards[i].isMatched) {
                                cards[i].flip();
                                flipSound.play(); // 카드 뒤집는 소리 재생
                                if (flippedCard == -1) {
                                    flippedCard = i;
                                }
                                else {
                                    if (cards[i].id != cards[flippedCard].id && cards[i].isSameColor(cards[flippedCard])) {
                                        cards[i].isMatched = true;
                                        cards[flippedCard].isMatched = true;
                                        score += 5; // 색상이 일치할 때 +5점
                                    }
                                    else {
                                        delay = true;
                                        clock.restart();
                                        score -= 1; // 색상이 일치하지 않을 때 -1점
                                    }
                                    flippedCard = -1;
                                    updateScoreText(); // 각 이동 후 점수 텍스트 업데이트
                                }
                                break;
                            }
                        }
                    }
                }
            }

            if (delay && clock.getElapsedTime().asSeconds() > 1) {
                for (Card& card : cards) {
                    if (card.isFlipped && !card.isMatched) {
                        card.flip();
                    }
                }
                delay = false;
            }

            if (allCardsMatched(cards)) {
                // 최종 점수 표시
                sf::Text finalScoreText;
                finalScoreText.setFont(font);
                finalScoreText.setCharacterSize(50);
                finalScoreText.setFillColor(sf::Color::White);
                finalScoreText.setString("Final Score: " + std::to_string(score));
                finalScoreText.setPosition((WINDOW_WIDTH - finalScoreText.getLocalBounds().width) / 2, (WINDOW_HEIGHT - finalScoreText.getLocalBounds().height) / 2);

                window.clear();
                window.draw(finalScoreText);
                window.display();

                // 게임이 끝나면 메뉴로 돌아가기 위해 잠시 기다림
                sf::sleep(sf::seconds(2));

                return true; // 모든 카드가 일치하면 메뉴로 돌아감
            }

            if (remainingTime <= 0) {
                // 시간이 다 되었을 때 최종 점수 표시
                sf::Text finalScoreText;
                finalScoreText.setFont(font);
                finalScoreText.setCharacterSize(50);
                finalScoreText.setFillColor(sf::Color::White);
                finalScoreText.setString("Time's up!");
                finalScoreText.setPosition((WINDOW_WIDTH - finalScoreText.getLocalBounds().width) / 2, (WINDOW_HEIGHT - finalScoreText.getLocalBounds().height) / 2);

                window.clear();
                window.draw(finalScoreText);
                window.display();

                // 게임이 끝나면 메뉴로 돌아가기 위해 잠시 기다림
                sf::sleep(sf::seconds(2));

                return true; // 시간이 다 되면 메뉴로 돌아감
            }

            updateTimerText(remainingTime);

            window.clear();
            for (const Card& card : cards) {
                window.draw(card.shape);
            }
            window.draw(scoreText); // 점수 텍스트 그리기
            window.draw(timerText); // 타이머 텍스트 그리기
            window.display();
        }
        return false; // 창이 닫혔을 경우
    }
};

class DifficultyMenu {
private:
    sf::RenderWindow& window;
    sf::Font font;
    sf::Texture backgroundTexture;
    sf::Sprite backgroundSprite;

public:
    DifficultyMenu(sf::RenderWindow& window) : window(window) {
        if (!font.loadFromFile("resources/tuffy.ttf")) {
            // 폰트 로드 실패
            // 오류 처리
        }

        if (!backgroundTexture.loadFromFile("resources/background.png")) {
            // 배경 이미지 로드 실패
            // 오류 처리
        }
        backgroundSprite.setTexture(backgroundTexture);
    }

    void run() {
        sf::Text title;
        title.setFont(font);
        title.setCharacterSize(75);
        title.setFillColor(sf::Color::White);
        title.setString("MEMORY GAME");
        title.setPosition((WINDOW_WIDTH - title.getLocalBounds().width) / 2, 100);

        sf::Text easyText;
        easyText.setFont(font);
        easyText.setCharacterSize(45);
        easyText.setFillColor(sf::Color::White);
        easyText.setString("Easy (4x4 Grid)");
        easyText.setPosition((WINDOW_WIDTH - easyText.getLocalBounds().width) / 2, 300);

        sf::Text hardText;
        hardText.setFont(font);
        hardText.setCharacterSize(45); // 폰트 크기를 증가시킵니다.
        hardText.setFillColor(sf::Color::White);
        hardText.setString("Hard (6x6 Grid)");
        hardText.setPosition((WINDOW_WIDTH - hardText.getLocalBounds().width) / 2, 400);

        // 배경 이미지 크기를 창의 크기와 동일하게 조정
        sf::FloatRect textureRect = backgroundSprite.getLocalBounds();
        backgroundSprite.setScale(WINDOW_WIDTH / textureRect.width, WINDOW_HEIGHT / textureRect.height);

        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    window.close();
                }
                else if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    if (easyText.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                        // 쉬운 모드 시작
                        Game game(window, 4, 4);
                        if (game.run()) {
                            run(); // 게임이 끝나면 메뉴를 다시 시작
                            return;
                        }
                    }
                    else if (hardText.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                        // 어려운 모드 시작
                        Game game(window, 6, 6);
                        if (game.run()) {
                            // 게임이 끝나면 메뉴를 다시 시작
                            run();
                            return;
                        }
                    }
                }
            }

            window.clear();
            window.draw(backgroundSprite); // 배경 이미지 그리기
            window.draw(title);
            window.draw(easyText);
            window.draw(hardText);
            window.display();
        }
    }
};

void Memorygamemain() {
    sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Memory Game");

    DifficultyMenu menu(window);
    menu.run();

    
}

