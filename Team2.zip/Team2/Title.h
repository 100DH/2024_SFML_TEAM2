#pragma once
void Memorygamemain();
void Dinogamemain();
void Icegamemain();

#include <SFML/Graphics.hpp>
#include <iostream>

class TitlePage {
public:
    TitlePage(sf::RenderWindow& window, sf::Font& font) : m_Window(window), m_Font(font) {
        m_TitleText.setString("Game Selection");
        m_TitleText.setFont(m_Font);
        m_TitleText.setCharacterSize(60);
        m_TitleText.setFillColor(sf::Color::Black);
        m_TitleText.setStyle(sf::Text::Bold);
        m_TitleText.setPosition(100.f, 100.f);

        m_DinoButtonText.setString("Play Dino Jump");
        m_DinoButtonText.setFont(m_Font);
        m_DinoButtonText.setCharacterSize(30);
        m_DinoButtonText.setFillColor(sf::Color::Black);
        m_DinoButtonText.setPosition(180.f, 250.f);

        m_IceButtonText.setString("Play Ice Game");
        m_IceButtonText.setFont(m_Font);
        m_IceButtonText.setCharacterSize(30);
        m_IceButtonText.setFillColor(sf::Color::Black);
        m_IceButtonText.setPosition(180.f, 300.f);

        m_MemoryButtonText.setString("Play Memory Game");
        m_MemoryButtonText.setFont(m_Font);
        m_MemoryButtonText.setCharacterSize(30);
        m_MemoryButtonText.setFillColor(sf::Color::Black);
        m_MemoryButtonText.setPosition(180.f, 350.f);
    }

    int show() {
        while (m_Window.isOpen()) {
            sf::Event event;
            while (m_Window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    m_Window.close();
                else if (event.type == sf::Event::MouseButtonPressed) {
                    if (event.mouseButton.button == sf::Mouse::Left) {
                        if (m_DinoButtonText.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
                            return 1; // Dino Jump ����
                        }
                        else if (m_IceButtonText.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
                            return 2; // Ice Game ����
                        }
                        else if (m_MemoryButtonText.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
                            return 3; // Memory Game ����
                        }
                    }
                }
                else if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
                    // ESC Ű�� ������ �� ���� ���� â���� ���ư���
                    return 0;
                }
            }

            m_Window.clear(sf::Color::White);
            m_Window.draw(m_TitleText);
            m_Window.draw(m_DinoButtonText);
            m_Window.draw(m_IceButtonText);
            m_Window.draw(m_MemoryButtonText);
            m_Window.display();
        }
        return 0;
    }


private:
    sf::RenderWindow& m_Window;
    sf::Font& m_Font;
    sf::Text m_TitleText;
    sf::Text m_DinoButtonText;
    sf::Text m_IceButtonText;
    sf::Text m_MemoryButtonText;
};